// ============================================================================
// Sistema de Gerenciamento de Tarefas - SENAI
// Arquivo: app.js
// Descrição: Lógica principal da aplicação
// ============================================================================

// Dados simulados (em uma aplicação real, viriam de um backend)
let usuarios = [
    { id: 1, nome: 'João Silva', email: 'joao.silva@empresa.com' },
    { id: 2, nome: 'Maria Santos', email: 'maria.santos@empresa.com' },
    { id: 3, nome: 'Pedro Oliveira', email: 'pedro.oliveira@empresa.com' },
    { id: 4, nome: 'Ana Costa', email: 'ana.costa@empresa.com' },
    { id: 5, nome: 'Carlos Ferreira', email: 'carlos.ferreira@empresa.com' }
];

let tarefas = [
    {
        id: 1,
        nome: 'Revisar Processo de Produção',
        descricao: 'Revisar e documentar o processo de produção da linha 1',
        setor: 'Produção',
        prioridade: 'alta',
        data_cadastro: new Date('2024-11-20'),
        status: 'a fazer',
        usuario_id: 1
    },
    {
        id: 2,
        nome: 'Atualizar Planilha de Controle',
        descricao: 'Atualizar a planilha de controle de qualidade do mês',
        setor: 'Qualidade',
        prioridade: 'média',
        data_cadastro: new Date('2024-11-21'),
        status: 'fazendo',
        usuario_id: 2
    },
    {
        id: 3,
        nome: 'Treinar Novos Operadores',
        descricao: 'Realizar treinamento com os novos operadores da linha 2',
        setor: 'Recursos Humanos',
        prioridade: 'alta',
        data_cadastro: new Date('2024-11-19'),
        status: 'a fazer',
        usuario_id: 3
    },
    {
        id: 4,
        nome: 'Manutenção Preventiva',
        descricao: 'Realizar manutenção preventiva das máquinas da linha 1',
        setor: 'Manutenção',
        prioridade: 'média',
        data_cadastro: new Date('2024-11-18'),
        status: 'pronto',
        usuario_id: 4
    },
    {
        id: 5,
        nome: 'Relatório de Vendas',
        descricao: 'Preparar relatório de vendas do trimestre',
        setor: 'Vendas',
        prioridade: 'baixa',
        data_cadastro: new Date('2024-11-22'),
        status: 'a fazer',
        usuario_id: 5
    }
];

let proximoIdTarefa = 6;

// ============================================================================
// Funções Utilitárias
// ============================================================================

/**
 * Formata uma data no formato DD/MM/YYYY
 */
function formatarData(data) {
    const d = new Date(data);
    const dia = String(d.getDate()).padStart(2, '0');
    const mes = String(d.getMonth() + 1).padStart(2, '0');
    const ano = d.getFullYear();
    return `${dia}/${mes}/${ano}`;
}

/**
 * Obtém o usuário pelo ID
 */
function obterUsuarioPorId(id) {
    return usuarios.find(u => u.id === id);
}

/**
 * Exibe uma mensagem de alerta
 */
function mostrarAlerta(mensagem, tipo = 'success') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${tipo}`;
    alertDiv.innerHTML = `
        <span>${mensagem}</span>
        <button class="close" onclick="this.parentElement.remove()">×</button>
    `;
    
    const container = document.querySelector('.container') || document.body;
    container.insertBefore(alertDiv, container.firstChild);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

/**
 * Valida um email
 */
function validarEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

/**
 * Verifica se um email já existe
 */
function emailJaExiste(email, idExcluir = null) {
    return usuarios.some(u => u.email === email && u.id !== idExcluir);
}

// ============================================================================
// Funções de Usuário
// ============================================================================

/**
 * Cadastra um novo usuário
 */
function cadastrarUsuario(nome, email) {
    // Validações
    if (!nome.trim()) {
        mostrarAlerta('O nome é obrigatório', 'error');
        return false;
    }

    if (!email.trim()) {
        mostrarAlerta('O email é obrigatório', 'error');
        return false;
    }

    if (!validarEmail(email)) {
        mostrarAlerta('Email inválido', 'error');
        return false;
    }

    if (emailJaExiste(email)) {
        mostrarAlerta('Este email já está cadastrado', 'error');
        return false;
    }

    // Criar novo usuário
    const novoUsuario = {
        id: Math.max(...usuarios.map(u => u.id), 0) + 1,
        nome: nome.trim(),
        email: email.trim()
    };

    usuarios.push(novoUsuario);
    mostrarAlerta('Cadastro concluído com sucesso', 'success');
    
    // Limpar formulário
    document.getElementById('formCadastroUsuario').reset();
    
    return true;
}

/**
 * Popula o select de usuários
 */
function preencherSelectUsuarios() {
    const selectUsuario = document.getElementById('usuario');
    if (!selectUsuario) return;

    selectUsuario.innerHTML = '<option value="">Selecione um usuário</option>';
    usuarios.forEach(usuario => {
        const option = document.createElement('option');
        option.value = usuario.id;
        option.textContent = usuario.nome;
        selectUsuario.appendChild(option);
    });
}

// ============================================================================
// Funções de Tarefa
// ============================================================================

/**
 * Cadastra uma nova tarefa
 */
function cadastrarTarefa(descricao, setor, usuarioId, prioridade) {
    // Validações
    if (!descricao.trim()) {
        mostrarAlerta('A descrição é obrigatória', 'error');
        return false;
    }

    if (!setor.trim()) {
        mostrarAlerta('O setor é obrigatório', 'error');
        return false;
    }

    if (!usuarioId) {
        mostrarAlerta('O usuário é obrigatório', 'error');
        return false;
    }

    if (!prioridade) {
        mostrarAlerta('A prioridade é obrigatória', 'error');
        return false;
    }

    // Criar nova tarefa
    const novaTarefa = {
        id: proximoIdTarefa++,
        nome: descricao.trim().substring(0, 50), // Usar os primeiros 50 caracteres como nome
        descricao: descricao.trim(),
        setor: setor.trim(),
        prioridade: prioridade,
        data_cadastro: new Date(),
        status: 'a fazer',
        usuario_id: parseInt(usuarioId)
    };

    tarefas.push(novaTarefa);
    mostrarAlerta('Cadastro concluído com sucesso', 'success');
    
    // Limpar formulário
    document.getElementById('formCadastroTarefa').reset();
    
    return true;
}

/**
 * Atualiza o status de uma tarefa
 */
function atualizarStatusTarefa(tarefaId, novoStatus) {
    const tarefa = tarefas.find(t => t.id === tarefaId);
    if (tarefa) {
        tarefa.status = novoStatus;
        renderizarKanban();
        mostrarAlerta('Status atualizado com sucesso', 'success');
    }
}

/**
 * Exclui uma tarefa
 */
function excluirTarefa(tarefaId) {
    if (confirm('Tem certeza que deseja excluir esta tarefa?')) {
        tarefas = tarefas.filter(t => t.id !== tarefaId);
        renderizarKanban();
        mostrarAlerta('Tarefa excluída com sucesso', 'success');
    }
}

/**
 * Edita uma tarefa
 */
function editarTarefa(tarefaId) {
    const tarefa = tarefas.find(t => t.id === tarefaId);
    if (!tarefa) return;

    // Preencher o formulário com os dados da tarefa
    document.getElementById('descricao').value = tarefa.descricao;
    document.getElementById('setor').value = tarefa.setor;
    document.getElementById('usuario').value = tarefa.usuario_id;
    document.getElementById('prioridade').value = tarefa.prioridade;
    
    // Armazenar o ID da tarefa sendo editada
    document.getElementById('formCadastroTarefa').dataset.editandoId = tarefaId;
    
    // Mudar o texto do botão
    const btnCadastrar = document.querySelector('#formCadastroTarefa button[type="submit"]');
    if (btnCadastrar) {
        btnCadastrar.textContent = 'Atualizar Tarefa';
    }
    
    // Scroll para o formulário
    document.getElementById('formCadastroTarefa').scrollIntoView({ behavior: 'smooth' });
}

/**
 * Salva a edição de uma tarefa
 */
function salvarEdicaoTarefa(descricao, setor, usuarioId, prioridade) {
    const formElement = document.getElementById('formCadastroTarefa');
    const tarefaId = parseInt(formElement.dataset.editandoId);

    if (!tarefaId) {
        return cadastrarTarefa(descricao, setor, usuarioId, prioridade);
    }

    // Validações
    if (!descricao.trim()) {
        mostrarAlerta('A descrição é obrigatória', 'error');
        return false;
    }

    if (!setor.trim()) {
        mostrarAlerta('O setor é obrigatório', 'error');
        return false;
    }

    if (!usuarioId) {
        mostrarAlerta('O usuário é obrigatório', 'error');
        return false;
    }

    if (!prioridade) {
        mostrarAlerta('A prioridade é obrigatória', 'error');
        return false;
    }

    // Atualizar tarefa
    const tarefa = tarefas.find(t => t.id === tarefaId);
    if (tarefa) {
        tarefa.nome = descricao.trim().substring(0, 50);
        tarefa.descricao = descricao.trim();
        tarefa.setor = setor.trim();
        tarefa.prioridade = prioridade;
        tarefa.usuario_id = parseInt(usuarioId);
        
        mostrarAlerta('Tarefa atualizada com sucesso', 'success');
        
        // Limpar formulário
        formElement.reset();
        delete formElement.dataset.editandoId;
        
        // Restaurar texto do botão
        const btnCadastrar = document.querySelector('#formCadastroTarefa button[type="submit"]');
        if (btnCadastrar) {
            btnCadastrar.textContent = 'Cadastrar Tarefa';
        }
        
        renderizarKanban();
        return true;
    }

    return false;
}

// ============================================================================
// Renderização do Kanban
// ============================================================================

/**
 * Renderiza o quadro Kanban
 */
function renderizarKanban() {
    const kanbanBoard = document.getElementById('kanbanBoard');
    if (!kanbanBoard) return;

    const statusList = ['a fazer', 'fazendo', 'pronto'];
    const statusLabels = {
        'a fazer': 'A Fazer',
        'fazendo': 'Fazendo',
        'pronto': 'Pronto'
    };

    kanbanBoard.innerHTML = '';

    statusList.forEach(status => {
        const tarefasDoStatus = tarefas.filter(t => t.status === status);
        
        const column = document.createElement('div');
        column.className = 'kanban-column';

        const header = document.createElement('div');
        header.className = `kanban-column-header ${status}`;
        header.textContent = `${statusLabels[status]} (${tarefasDoStatus.length})`;
        column.appendChild(header);

        const cardsContainer = document.createElement('div');
        cardsContainer.className = 'kanban-cards';

        tarefasDoStatus.forEach(tarefa => {
            const usuario = obterUsuarioPorId(tarefa.usuario_id);
            const card = document.createElement('div');
            card.className = 'kanban-card';

            card.innerHTML = `
                <div class="kanban-card-header">
                    <div class="kanban-card-title">${tarefa.nome}</div>
                    <span class="kanban-card-priority priority-${tarefa.prioridade}">
                        ${tarefa.prioridade.charAt(0).toUpperCase() + tarefa.prioridade.slice(1)}
                    </span>
                </div>
                <div class="kanban-card-description">${tarefa.descricao}</div>
                <div class="kanban-card-meta">
                    <div class="kanban-card-meta-item">
                        <span class="kanban-card-meta-label">Setor:</span>
                        <span class="kanban-card-meta-value">${tarefa.setor}</span>
                    </div>
                    <div class="kanban-card-meta-item">
                        <span class="kanban-card-meta-label">Responsável:</span>
                        <span class="kanban-card-meta-value">${usuario ? usuario.nome : 'N/A'}</span>
                    </div>
                    <div class="kanban-card-meta-item">
                        <span class="kanban-card-meta-label">Cadastro:</span>
                        <span class="kanban-card-meta-value">${formatarData(tarefa.data_cadastro)}</span>
                    </div>
                    <div class="kanban-card-meta-item">
                        <span class="kanban-card-meta-label">Status:</span>
                        <span class="kanban-card-meta-value">${statusLabels[tarefa.status]}</span>
                    </div>
                </div>
                <div class="kanban-card-status">
                    <select onchange="atualizarStatusTarefa(${tarefa.id}, this.value)">
                        <option value="a fazer" ${tarefa.status === 'a fazer' ? 'selected' : ''}>A Fazer</option>
                        <option value="fazendo" ${tarefa.status === 'fazendo' ? 'selected' : ''}>Fazendo</option>
                        <option value="pronto" ${tarefa.status === 'pronto' ? 'selected' : ''}>Pronto</option>
                    </select>
                </div>
                <div class="kanban-card-actions">
                    <button class="btn btn-primary btn-small" onclick="editarTarefa(${tarefa.id})">Editar</button>
                    <button class="btn btn-danger btn-small" onclick="excluirTarefa(${tarefa.id})">Excluir</button>
                </div>
            `;

            cardsContainer.appendChild(card);
        });

        column.appendChild(cardsContainer);
        kanbanBoard.appendChild(column);
    });
}

// ============================================================================
// Inicialização
// ============================================================================

document.addEventListener('DOMContentLoaded', function() {
    // Preencher select de usuários ao carregar a página
    preencherSelectUsuarios();

    // Renderizar Kanban ao carregar a página
    renderizarKanban();

    // Configurar formulário de cadastro de usuário
    const formUsuario = document.getElementById('formCadastroUsuario');
    if (formUsuario) {
        formUsuario.addEventListener('submit', function(e) {
            e.preventDefault();
            const nome = document.getElementById('nome').value;
            const email = document.getElementById('email').value;
            cadastrarUsuario(nome, email);
            preencherSelectUsuarios();
        });
    }

    // Configurar formulário de cadastro de tarefa
    const formTarefa = document.getElementById('formCadastroTarefa');
    if (formTarefa) {
        formTarefa.addEventListener('submit', function(e) {
            e.preventDefault();
            const descricao = document.getElementById('descricao').value;
            const setor = document.getElementById('setor').value;
            const usuarioId = document.getElementById('usuario').value;
            const prioridade = document.getElementById('prioridade').value;
            
            const editandoId = formTarefa.dataset.editandoId;
            if (editandoId) {
                salvarEdicaoTarefa(descricao, setor, usuarioId, prioridade);
            } else {
                cadastrarTarefa(descricao, setor, usuarioId, prioridade);
            }
            renderizarKanban();
        });
    }

    // Configurar navegação
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('data-page');
            
            // Remover classe active de todos os links
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            // Esconder todas as páginas
            document.querySelectorAll('[data-page]').forEach(page => {
                page.classList.add('hidden');
            });
            
            // Mostrar página selecionada
            const pageElement = document.querySelector(`[data-page="${page}"]`);
            if (pageElement) {
                pageElement.classList.remove('hidden');
            }
        });
    });

    // Ativar a primeira página por padrão
    const primeiroLink = document.querySelector('nav a');
    if (primeiroLink) {
        primeiroLink.click();
    }
});
