# Sistema de Gerenciamento de Tarefas - SENAI

## Descrição

Este é um sistema web de gerenciamento de tarefas (Kanban) desenvolvido para o SENAI. O sistema permite cadastrar usuários, criar tarefas e gerenciá-las em um quadro Kanban com três status: **A Fazer**, **Fazendo** e **Pronto**.

## Características

- **Cadastro de Usuários**: Crie novos usuários que poderão ser responsáveis pelas tarefas
- **Cadastro de Tarefas**: Crie tarefas com descrição, setor, prioridade e responsável
- **Quadro Kanban**: Visualize todas as tarefas organizadas por status
- **Edição de Tarefas**: Edite as informações de uma tarefa existente
- **Exclusão de Tarefas**: Remova tarefas do sistema
- **Alteração de Status**: Mude o status de uma tarefa com um simples clique
- **Design Responsivo**: Interface adaptada para diferentes tamanhos de tela

## Estrutura de Arquivos

```
joao_hoffmann_kanban/
├── index.html           # Arquivo HTML principal
├── css/
│   └── style.css        # Estilos CSS da aplicação
├── js/
│   └── app.js           # Lógica JavaScript da aplicação
└── README.md            # Este arquivo
```

## Como Usar

1. **Abra o arquivo `index.html`** em um navegador web moderno (Chrome, Firefox, Safari, Edge)

2. **Navegação**: Use o menu no topo para alternar entre as três seções:
   - **Cadastro de Usuários**: Crie novos usuários
   - **Cadastro de Tarefas**: Crie novas tarefas
   - **Gerenciamento de Tarefas**: Visualize e gerencie o quadro Kanban

3. **Cadastro de Usuários**:
   - Preencha o nome e email
   - Clique em "Cadastrar"
   - Uma mensagem de sucesso será exibida

4. **Cadastro de Tarefas**:
   - Preencha a descrição da tarefa
   - Selecione o setor
   - Escolha o usuário responsável
   - Selecione a prioridade (Baixa, Média, Alta)
   - Clique em "Cadastrar Tarefa"

5. **Gerenciamento de Tarefas**:
   - Visualize as tarefas organizadas em três colunas
   - Use o dropdown de status para mover uma tarefa entre colunas
   - Clique em "Editar" para modificar uma tarefa
   - Clique em "Excluir" para remover uma tarefa

## Regras de Negócio

- Todos os campos de cadastro são obrigatórios
- O email deve ser válido e único
- Uma tarefa é criada com status padrão "A Fazer"
- Um usuário pode cadastrar múltiplas tarefas
- Uma tarefa é cadastrada por apenas um usuário
- A integridade das informações é garantida pela validação de campos obrigatórios

## Padrões de Design

- **Fonte**: Segoe UI
- **Cor Principal**: Azul SENAI (#0056b3)
- **Cores de Prioridade**:
  - Baixa: Verde
  - Média: Amarelo
  - Alta: Vermelho

## Dados Persistentes

Os dados são armazenados em memória durante a sessão do navegador. Para uma aplicação em produção, seria necessário integrar um backend com banco de dados.

## Requisitos Técnicos

- Navegador web moderno com suporte a:
  - HTML5
  - CSS3
  - JavaScript ES6+

## Autor

Desenvolvido como avaliação prática de desempenho dos estudantes do SENAI.

## Licença

Este projeto é fornecido como material educacional do SENAI.
