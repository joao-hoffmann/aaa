-- ============================================================================
-- Script de Criação do Banco de Dados - Sistema de Gerenciamento de Tarefas
-- SENAI - Avaliação Prática de Desempenho dos Estudantes
-- Aluno: João Hoffmann
-- ============================================================================

-- Criar o banco de dados
CREATE DATABASE IF NOT EXISTS gerenciamento_tarefas;
USE gerenciamento_tarefas;

-- ============================================================================
-- Tabela: USUARIO
-- Descrição: Armazena os dados dos usuários que cadastram tarefas
-- ============================================================================
CREATE TABLE usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Tabela: TAREFA
-- Descrição: Armazena as tarefas cadastradas pelos usuários
-- ============================================================================
CREATE TABLE tarefa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(200) NOT NULL,
    descricao TEXT NOT NULL,
    setor VARCHAR(100) NOT NULL,
    prioridade ENUM('baixa', 'média', 'alta') NOT NULL,
    data_cadastro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status ENUM('a fazer', 'fazendo', 'pronto') NOT NULL DEFAULT 'a fazer',
    usuario_id INT NOT NULL,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE CASCADE,
    INDEX idx_usuario_id (usuario_id),
    INDEX idx_status (status),
    INDEX idx_data_cadastro (data_cadastro)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Dados de Exemplo
-- ============================================================================

-- Inserir usuários de exemplo
INSERT INTO usuario (nome, email) VALUES
('João Silva', 'joao.silva@empresa.com'),
('Maria Santos', 'maria.santos@empresa.com'),
('Pedro Oliveira', 'pedro.oliveira@empresa.com'),
('Ana Costa', 'ana.costa@empresa.com'),
('Carlos Ferreira', 'carlos.ferreira@empresa.com');

-- Inserir tarefas de exemplo
INSERT INTO tarefa (nome, descricao, setor, prioridade, data_cadastro, status, usuario_id) VALUES
('Revisar Processo de Produção', 'Revisar e documentar o processo de produção da linha 1', 'Produção', 'alta', NOW(), 'a fazer', 1),
('Atualizar Planilha de Controle', 'Atualizar a planilha de controle de qualidade do mês', 'Qualidade', 'média', NOW(), 'fazendo', 2),
('Treinar Novos Operadores', 'Realizar treinamento com os novos operadores da linha 2', 'Recursos Humanos', 'alta', NOW(), 'a fazer', 3),
('Manutenção Preventiva', 'Realizar manutenção preventiva das máquinas da linha 1', 'Manutenção', 'média', NOW(), 'pronto', 4),
('Relatório de Vendas', 'Preparar relatório de vendas do trimestre', 'Vendas', 'baixa', NOW(), 'a fazer', 5),
('Auditoria de Estoque', 'Realizar auditoria completa do estoque de matérias-primas', 'Logística', 'alta', NOW(), 'fazendo', 1),
('Análise de Custos', 'Analisar custos de produção do último mês', 'Financeiro', 'média', NOW(), 'a fazer', 2),
('Limpeza e Higiene', 'Limpeza profunda da área de produção', 'Limpeza', 'baixa', NOW(), 'pronto', 3);

-- ============================================================================
-- Verificação das Tabelas Criadas
-- ============================================================================
-- SELECT * FROM usuario;
-- SELECT * FROM tarefa;
